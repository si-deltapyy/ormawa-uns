<?php
 
phpinfo();
 
?>