<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <link rel="shortcut icon" href="<?php echo e(asset('img/logo-uns.png')); ?>" />

    <!-- Scripts -->
    

    <!-- App css -->
    <link href=<?php echo e(asset('assets/css/bootstrap.min.css')); ?> rel="stylesheet" type="text/css" />
    <link href=<?php echo e(asset('assets/css/icons.min.css')); ?> rel="stylesheet" type="text/css" />
    <link href=<?php echo e(asset('assets/css/theme.min.css')); ?> rel="stylesheet" type="text/css" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    

    <link href=<?php echo e(asset('../plugins/datatables/dataTables.bootstrap4.css')); ?> rel="stylesheet" type="text/css" />
    <link href=<?php echo e(asset('../plugins/datatables/responsive.bootstrap4.css')); ?> rel="stylesheet" type="text/css" />
    <link href=<?php echo e(asset('../plugins/datatables/buttons.bootstrap4.css')); ?> rel="stylesheet" type="text/css" />
    <link href=<?php echo e(asset('../plugins/datatables/select.bootstrap4.css')); ?> rel="stylesheet" type="text/css" />
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'user|ormawa|pembina')): ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom-sidebar.css')); ?>">
    <?php endif; ?>

    <?php echo $__env->yieldContent('head'); ?>

</head>



<body>

    <!-- Begin page -->
    <div id="layout-wrapper">

        <header id="page-topbar">
            <?php echo $__env->make('component.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </header>

        <!-- ========== Left Sidebar Start ========== -->
        <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'user|ormawa|pembina')): ?>
        <div class="vertical-menu" style="background-color: #fff;">
        <?php endif; ?>
        <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'admin|super-admin|stakeholder')): ?>
        <div class="vertical-menu" >
        <?php endif; ?>
            <div data-simplebar class="h-100">

                <div class="navbar-brand-box">
                    <a href="javascript:void(0);" class="logo">
                        <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'admin|super-admin|stakeholder')): ?>
                        <span>
                            DIRMAWA UNS
                        </span>
                        <?php endif; ?>
                        <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'user|ormawa|pembina')): ?>
                        <span style="color: #000">
                            ORMAWA UNS
                        </span>
                        <?php endif; ?>
                    </a>
                </div>

                <!--- Sidemenu -->
                <?php echo $__env->make('component.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- Sidebar -->
            </div>
        </div>

        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">

                    <!-- start page title -->
                    <?php echo $__env->yieldContent('content'); ?>

                    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div> <!-- container-fluid -->
            </div>
            <!-- End Page-content -->

            <?php echo $__env->make('component.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
        <!-- end main content-->

    </div>
    <!-- END layout-wrapper -->

    <!-- Overlay-->
    <div class="menu-overlay"></div>


    <!-- jQuery  -->
    <script src=<?php echo e(asset('assets/js/jquery.min.js')); ?>></script>
    <script src=<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>></script>
    <script src=<?php echo e(asset('assets/js/metismenu.min.js')); ?>></script>
    <script src=<?php echo e(asset('assets/js/waves.js')); ?>></script>
    <script src=<?php echo e(asset('assets/js/simplebar.min.js')); ?>></script>
    
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <!-- Morris Js-->
    <script src=<?php echo e(asset('../plugins/morris-js/morris.min.js')); ?>></script>
    <!-- Raphael Js-->
    <script src=<?php echo e(asset('../plugins/raphael/raphael.min.js')); ?>></script>
    <script src=<?php echo e(asset('../plugins/chart-js/chart.min.js')); ?>></script>

    <!-- Morris Custom Js-->
    <script src=<?php echo e(asset('assets/pages/dashboard-demo.js')); ?>></script>

    <!-- App js -->
    <script src=<?php echo e(asset('assets/js/theme.js')); ?>></script>

    <script src=<?php echo e(asset('../plugins/datatables/jquery.dataTables.min.js')); ?>></script>
    <script src=<?php echo e(asset('../plugins/datatables/dataTables.bootstrap4.js')); ?>></script>
    <script src=<?php echo e(asset('../plugins/datatables/dataTables.responsive.min.js')); ?>></script>
    <script src=<?php echo e(asset('../plugins/datatables/responsive.bootstrap4.min.js')); ?>></script>
    <script src=<?php echo e(asset('../plugins/datatables/dataTables.buttons.min.js')); ?>></script>
    <script src=<?php echo e(asset('../plugins/datatables/buttons.bootstrap4.min.js')); ?>></script>
    <script src=<?php echo e(asset('../plugins/datatables/buttons.html5.min.js')); ?>></script>
    <script src=<?php echo e(asset('../plugins/datatables/buttons.flash.min.js')); ?>></script>
    <script src=<?php echo e(asset('../plugins/datatables/buttons.print.min.js')); ?>></script>
    <script src=<?php echo e(asset('../plugins/datatables/dataTables.keyTable.min.js')); ?>></script>
    <script src=<?php echo e(asset('../plugins/datatables/dataTables.select.min.js')); ?>></script>
    <script src=<?php echo e(asset('../plugins/datatables/pdfmake.min.js')); ?>></script>
    <script src=<?php echo e(asset('../plugins/datatables/vfs_fonts.js')); ?>></script>

    <?php echo $__env->yieldContent('scripts'); ?>

</body>

</html><?php /**PATH D:\Project\Other\form-ormawa-uns\ormawa-uns\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>