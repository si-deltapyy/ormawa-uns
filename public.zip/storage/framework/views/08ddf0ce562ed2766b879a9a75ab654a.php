<div id="sidebar-menu">
    <!-- Left Menu Start -->
    <ul class="metismenu list-unstyled" id="side-menu">
        
        <?php if (\Illuminate\Support\Facades\Blade::check('role', 'super-admin')): ?>
        <li>
            <a href="<?php echo e(route('admin.index')); ?>" class="waves-effect"><i class="feather-airplay"></i>
                
                <span>Dashboard</span>
            </a>
        </li>
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect"><i class="feather-users"></i>
                <span>User Management</span></a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(route('role.index')); ?>">Manage Role</a></li>
                <li><a href="pages-starter.html">Edit User</a></li>
            </ul>
        </li>
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect"><i
                    class="feather-copy"></i><span>Pages</span></a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="pages-invoice.html">Invoice</a></li>
                <li><a href="pages-starter.html">Starter Page</a></li>
            </ul>
        </li>
        <?php endif; ?>

        <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
        
        <li class="menu-title">Menu</li>
        <li>
            <a href="<?php echo e(route('admin.index')); ?>" class="waves-effect"><i class="feather-airplay"></i>
                
                <span>Dashboard</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.review.proker')); ?>" class="waves-effect"><i
                class="feather-file-plus"></i>
                <?php if(Auth::user()->name == 'Admin TOR'): ?>
                    <span>Review Proker</span>
                <?php elseif(Auth::user()->name == 'Admin RAB'): ?>
                    <span>Review RAB</span>
                <?php endif; ?>
            </a>
        </li>
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect"><i class="feather-users"></i>
                <span>Data Surat</span></a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="#">SPJ</a></li>
                <li><a href="#">LPJ</a></li>
                <li><a href="#">SK</a></li>
                <li><a href="#">Surat Masuk</a></li>
                <li><a href="#">Surat Keluar</a></li>
            </ul>
        </li>
        <li class="menu-title">Setting</li>
        
        <li>
            <a href="#" class="waves-effect"><i
                    class="feather-book"></i><span>Log Aktivitas</span></a>
        </li>
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect"><i
                    class="feather-settings"></i><span>Pengaturan</span></a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="#">Atur Timeline</a></li>
                <li><a href="#">Pengaturan Aplikasi</a></li>
            </ul>
        </li>
        <li>
            <a href="#" class="waves-effect"><i
                    class="mdi mdi-whatsapp"></i><span>Whatsapp Config</span></a>
        </li>
        <li>
            <a href="#" class="waves-effect"><i
                    class="feather-help-circle"></i><span>Help & Support</span></a>
        </li>
        <?php endif; ?>

        
        <?php if (\Illuminate\Support\Facades\Blade::check('role', 'user')): ?>
        <li class="menu-title">Menu</li>
        <li>
            <a href="<?php echo e(route('user.index')); ?>" class="waves-effect" ><i class="feather-airplay"></i>
                
                <span>Dashboard</span></a>
        </li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ketua-ormawa')): ?>
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect"><i class="mdi mdi-file-document-box-plus-outline"></i>
                <span>Pengajuan</span></a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(route('user.ajuan.proker')); ?>">Ajuan Proker</a></li>
                <li><a href="#" class="sidebar-link disabled"><del>Ajuan SPJ / LPJ</del></a></li>
                <li><a href="#" class="sidebar-link disabled"><del>Ajuan SK</del></a></li>
            </ul>
        </li>
        <li>
            <a href="#" class="waves-effect sidebar-link disabled"><i class="feather-users"></i>
                <span><del>Kegiatan Ormawa</del></span></a>
        </li>
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect"><i class="feather-file-text"></i>
                <span>Laporan Kegiatan</span></a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="#">Laporan Proker</a></li>
                <li><a href="#" class="sidebar-link disabled"><del>SPJ / LPJ</del></a></li>
            </ul>
        </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pembina-ormawa')): ?>
            <li>
                <a href="javascript: void(0);" class="has-arrow waves-effect"><i class="mdi mdi-file-document-box-plus-outline"></i>
                    <span>Program Kerja</span></a>
                <ul class="sub-menu" aria-expanded="false">
                    <li><a href="<?php echo e(route('user.ajuan.proker')); ?>">Review</a></li>
                </ul>
            </li>
        <?php endif; ?>
        

        
        <li class="menu-title">Data</li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ketua-ormawa')): ?>
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect"><i class="mdi mdi-file-document-box-plus-outline"></i>
                <span>Data Ormawa</span></a>
            <ul class="sub-menu" aria-expanded="false">
                
                <li><a href="#">Anggota</a></li>
                <li><a href="<?php echo e(route('user.input.indikator.edit', Auth::user()->anggota->ormawa_id)); ?>">Update Indikator Utama</a></li>
            </ul>
        </li>
        <li>
            <a href="#" class="waves-effect sidebar-link disabled"><i class="feather-calendar"></i><span
                    class="badge badge-pill badge-primary float-right"></span><span><del>Jadwal Ormawa</del></span></a>
        </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pembina-ormawa')): ?>
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect"><i class="mdi mdi-file-document-box-plus-outline"></i>
                <span>Data Ormawa</span></a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(route('pembina.verify.anggota')); ?>">Verifikasi Anggota</a></li>
            </ul>
        </li>
        <?php endif; ?>
        <?php endif; ?>

        <?php if (\Illuminate\Support\Facades\Blade::check('role', 'ormawa')): ?>
            <li class="menu-title">Data Ormawa</li>
            <li>
                <a href="javascript: void(0);" class="has-arrow waves-effect"><i class="mdi mdi-file-document-box-plus-outline"></i>
                    <span>Data Ormawa</span></a>
                <ul class="sub-menu" aria-expanded="false">
                    <li><a href="#">Informasi</a></li>
                    <li><a href="#">Kelola Anggota</a></li>
                </ul>
            </li>
            <li>
                <a href="#" class="waves-effect"><i class="feather-calendar"></i><span
                        class="badge badge-pill badge-primary float-right"></span><span><del>Jadwal Ormawa</del></span></a>
            </li>
        <?php endif; ?>
        
            <li style="position: absolute; bottom: 20px; width: 100%; border-top: 1px solid rgba(255,255,255,0.1); background-color: inherit;">
                <form action="<?php echo e(route('logout')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="dropdown-item d-flex align-items-center text-danger mb-2">
                        <i class="mdi mdi-logout mr-2 text-danger font-16"></i> Logout
                    </button>
                </form>
            </li>
    </ul>
</div> 




<?php /**PATH D:\Project\Other\form-ormawa-uns\ormawa-uns\resources\views/component/sidebar.blade.php ENDPATH**/ ?>