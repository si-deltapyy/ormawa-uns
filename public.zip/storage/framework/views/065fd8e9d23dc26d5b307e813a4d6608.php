<div class="navbar-header">

    <div class="d-flex align-items-left">
        <button type="button" class="btn btn-sm mr-2 d-lg-none px-3 font-size-16 header-item waves-effect"
            id="vertical-menu-btn">
            <i class="fa fa-fw fa-bars"></i>
        </button>

        
    </div>

    <div class="d-flex align-items-center">

        

        

        

        <div class="dropdown d-inline-block ml-2">
            <button type="button" class="btn header-item waves-effect" id="page-header-user-dropdown"
                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <img class="rounded-circle header-profile-user" src=<?php echo e(asset("assets/images/users/1.png")); ?>

                    alt="Header Avatar">
                <span class="d-none d-sm-inline-block ml-1"><?php echo e((Auth::user()->name) ?? ''); ?></span>
                
            </button>
            
        </div>

    </div>
</div><?php /**PATH D:\Project\Other\form-ormawa-uns\ormawa-uns\resources\views/component/header.blade.php ENDPATH**/ ?>