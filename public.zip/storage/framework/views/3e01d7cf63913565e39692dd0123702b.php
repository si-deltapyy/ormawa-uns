<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between mb-3">
        <h3>Preview Anggaran</h3>
        <a href="<?php echo e(route('anggaran.index', ['id' => $id, 'export' => 'excel'])); ?>" class="btn btn-success">
            Download Excel
        </a>
    </div>

    <div class="card p-4 shadow-sm" style="overflow-x: auto;">
        
        <?php echo $__env->make('exports.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between mb-3">
        <h3>Preview Anggaran</h3>
        <a href="<?php echo e(route('anggaran.index', ['id' => $id, 'export' => 'excel'])); ?>" class="btn btn-success">
            Download Excel
        </a>
    </div>

    <div class="card p-4 shadow-sm" style="overflow-x: auto;">
        
        <?php echo $__env->make('exports.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Other\form-ormawa-uns\ormawa-uns\resources\views/exports/anggaran_excel.blade.php ENDPATH**/ ?>