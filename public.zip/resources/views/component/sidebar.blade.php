<div id="sidebar-menu">
    <!-- Left Menu Start -->
    <ul class="metismenu list-unstyled" id="side-menu">
        {{-- Role Admin --}}
        @role('super-admin')
        <li>
            <a href="{{ route('admin.index') }}" class="waves-effect"><i class="feather-airplay"></i>
                {{-- <span class="badge badge-pill badge-primary float-right">7</span> --}}
                <span>Dashboard</span>
            </a>
        </li>
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect"><i class="feather-users"></i>
                <span>User Management</span></a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="{{ route('role.index') }}">Manage Role</a></li>
                <li><a href="pages-starter.html">Edit User</a></li>
            </ul>
        </li>
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect"><i
                    class="feather-copy"></i><span>Pages</span></a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="pages-invoice.html">Invoice</a></li>
                <li><a href="pages-starter.html">Starter Page</a></li>
            </ul>
        </li>
        @endrole

        @role('admin')
        
        <li class="menu-title">Menu</li>
        <li>
            <a href="{{ route('admin.index') }}" class="waves-effect"><i class="feather-airplay"></i>
                {{-- <span class="badge badge-pill badge-primary float-right">7</span> --}}
                <span>Dashboard</span>
            </a>
        </li>
        <li>
            <a href="{{ route('admin.review.proker') }}" class="waves-effect"><i
                class="feather-file-plus"></i>
                @if (Auth::user()->name == 'Admin TOR')
                    <span>Review Proker</span>
                @elseif (Auth::user()->name == 'Admin RAB')
                    <span>Review RAB</span>
                @endif
            </a>
        </li>
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect"><i class="feather-users"></i>
                <span>Data Surat</span></a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="#">SPJ</a></li>
                <li><a href="#">LPJ</a></li>
                <li><a href="#">SK</a></li>
                <li><a href="#">Surat Masuk</a></li>
                <li><a href="#">Surat Keluar</a></li>
            </ul>
        </li>
        <li class="menu-title">Setting</li>
        
        <li>
            <a href="#" class="waves-effect"><i
                    class="feather-book"></i><span>Log Aktivitas</span></a>
        </li>
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect"><i
                    class="feather-settings"></i><span>Pengaturan</span></a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="#">Atur Timeline</a></li>
                <li><a href="#">Pengaturan Aplikasi</a></li>
            </ul>
        </li>
        <li>
            <a href="#" class="waves-effect"><i
                    class="mdi mdi-whatsapp"></i><span>Whatsapp Config</span></a>
        </li>
        <li>
            <a href="#" class="waves-effect"><i
                    class="feather-help-circle"></i><span>Help & Support</span></a>
        </li>
        @endrole

        {{-- Role User --}}
        @role('user')
        <li class="menu-title">Menu</li>
        <li>
            <a href="{{ route('user.index') }}" class="waves-effect" ><i class="feather-airplay"></i>
                {{-- <span class="badge badge-pill badge-primary float-right">7</span> --}}
                <span>Dashboard</span></a>
        </li>
        @can('ketua-ormawa')
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect"><i class="mdi mdi-file-document-box-plus-outline"></i>
                <span>Pengajuan</span></a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="{{ route('user.ajuan.proker') }}">Ajuan Proker</a></li>
                <li><a href="#" class="sidebar-link disabled"><del>Ajuan SPJ / LPJ</del></a></li>
                <li><a href="#" class="sidebar-link disabled"><del>Ajuan SK</del></a></li>
            </ul>
        </li>
        <li>
            <a href="#" class="waves-effect sidebar-link disabled"><i class="feather-users"></i>
                <span><del>Kegiatan Ormawa</del></span></a>
        </li>
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect"><i class="feather-file-text"></i>
                <span>Laporan Kegiatan</span></a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="#">Laporan Proker</a></li>
                <li><a href="#" class="sidebar-link disabled"><del>SPJ / LPJ</del></a></li>
            </ul>
        </li>
        @endcan
        @can('pembina-ormawa')
            <li>
                <a href="javascript: void(0);" class="has-arrow waves-effect"><i class="mdi mdi-file-document-box-plus-outline"></i>
                    <span>Program Kerja</span></a>
                <ul class="sub-menu" aria-expanded="false">
                    <li><a href="{{ route('user.ajuan.proker') }}">Review</a></li>
                </ul>
            </li>
        @endcan
        {{-- <li>
            <a href="#" class="waves-effect sidebar-link disabled"><i class="feather-bell"></i><span
                    class="badge badge-pill badge-danger float-right">6</span><span><del>Notifikasi</del></span></a>
        </li> --}}

        
        <li class="menu-title">Data</li>
        @can('ketua-ormawa')
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect"><i class="mdi mdi-file-document-box-plus-outline"></i>
                <span>Data Ormawa</span></a>
            <ul class="sub-menu" aria-expanded="false">
                {{-- <li><a href="#">Informasi</a></li>
                <li><a href="#">Dokumen</a></li> --}}
                <li><a href="#">Anggota</a></li>
                <li><a href="{{ route('user.input.indikator.edit', Auth::user()->anggota->ormawa_id) }}">Update Indikator Utama</a></li>
            </ul>
        </li>
        <li>
            <a href="#" class="waves-effect sidebar-link disabled"><i class="feather-calendar"></i><span
                    class="badge badge-pill badge-primary float-right"></span><span><del>Jadwal Ormawa</del></span></a>
        </li>
        @endcan
        @can('pembina-ormawa')
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect"><i class="mdi mdi-file-document-box-plus-outline"></i>
                <span>Data Ormawa</span></a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="{{ route('pembina.verify.anggota') }}">Verifikasi Anggota</a></li>
            </ul>
        </li>
        @endcan
        @endrole

        @role('ormawa')
            <li class="menu-title">Data Ormawa</li>
            <li>
                <a href="javascript: void(0);" class="has-arrow waves-effect"><i class="mdi mdi-file-document-box-plus-outline"></i>
                    <span>Data Ormawa</span></a>
                <ul class="sub-menu" aria-expanded="false">
                    <li><a href="#">Informasi</a></li>
                    <li><a href="#">Kelola Anggota</a></li>
                </ul>
            </li>
            <li>
                <a href="#" class="waves-effect"><i class="feather-calendar"></i><span
                        class="badge badge-pill badge-primary float-right"></span><span><del>Jadwal Ormawa</del></span></a>
            </li>
        @endrole
        {{-- Logout --}}
            <li style="position: absolute; bottom: 20px; width: 100%; border-top: 1px solid rgba(255,255,255,0.1); background-color: inherit;">
                <form action="{{ route('logout') }}" method="post">
                    @csrf
                    <button type="submit" class="dropdown-item d-flex align-items-center text-danger mb-2">
                        <i class="mdi mdi-logout mr-2 text-danger font-16"></i> Logout
                    </button>
                </form>
            </li>
    </ul>
</div> 



{{-- <div id="sidebar-menu">
    <!-- Left Menu Start -->
    <ul class="metismenu list-unstyled" id="side-menu">
        <li class="menu-title">Menu</li>

        <li>
            <a href="index.html" class="waves-effect"><i class="feather-airplay"></i><span
                    class="badge badge-pill badge-primary float-right">7</span><span>Dashboard</span></a>
        </li>

        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect"><i
                    class="feather-copy"></i><span>Pages</span></a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="pages-invoice.html">Invoice</a></li>
                <li><a href="pages-starter.html">Starter Page</a></li>
                <li><a href="pages-maintenance.html">Maintenance</a></li>
                <li><a href="pages-faqs.html">FAQs</a></li>
                <li><a href="pages-pricing.html">Pricing</a></li>
                <li><a href="pages-login.html">Login</a></li>
                <li><a href="pages-register.html">Register</a></li>
                <li><a href="pages-recoverpw.html">Recover Password</a></li>
                <li><a href="pages-lock-screen.html">Lock Screen</a></li>
                <li><a href="pages-404.html">Error 404</a></li>
                <li><a href="pages-500.html">Error 500</a></li>
            </ul>
        </li>

        <li><a href="calendar.html" class=" waves-effect"><i
                    class="feather-calendar"></i><span>Calendar</span></a></li>

        <li class="menu-title">Components</li>

        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect"><i
                    class="feather-briefcase"></i><span>UI Elements</span></a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="ui-buttons.html">Buttons</a></li>
                <li><a href="ui-cards.html">Cards</a></li>
                <li><a href="ui-carousel.html">Carousel</a>
                <li><a href="ui-embeds.html">Embeds</a>
                <li><a href="ui-general.html">General</a></li>
                <li><a href="ui-grid.html">Grid</a></li>
                <li><a href="ui-media-objects.html">Media Objects</a></li>
                <li><a href="ui-modals.html">Modals</a></li>
                <li><a href="ui-progressbars.html">Progress Bars</a></li>
                <li><a href="ui-tabs.html">Tabs</a></li>
                <li><a href="ui-typography.html">Typography</a></li>
                <li><a href="ui-toasts.html">Toasts</a></li>
                <li><a href="ui-tooltips-popovers.html">Tooltips & Popovers</a></li>
                <li><a href="ui-scrollspy.html">Scrollspy</a></li>
                <li><a href="ui-spinners.html">Spinners</a></li>
                <li><a href="ui-sweetalerts.html">Sweet Alerts</a></li>
            </ul>
        </li>

        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect"><i
                    class="feather-list"></i><span>Tables</span></a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="tables-basic.html">Basic Tables</a></li>
                <li><a href="tables-datatables.html">Data Tables</a></li>
            </ul>
        </li>

        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect"><i
                    class="feather-bar-chart-2"></i><span>Charts</span></a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="charts-morris.html">Morris</a></li>
                <li><a href="charts-google.html">Google</a></li>
                <li><a href="charts-chartjs.html">Chartjs</a></li>
                <li><a href="charts-sparkline.html">Sparkline</a></li>
                <li><a href="charts-knob.html">Jquery Knob</a></li>
            </ul>
        </li>

        <li>
            <a href="javascript: void(0);" class="waves-effect"><i class="feather-book"></i><span
                    class="badge badge-pill badge-danger float-right">6</span><span>Forms</span></a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="forms-elements.html">Elements</a></li>
                <li><a href="forms-plugins.html">Plugins</a></li>
                <li><a href="forms-validation.html">Validation</a></li>
                <li><a href="forms-mask.html">Masks</a></li>
                <li><a href="forms-quilljs.html">Quilljs</a></li>
                <li><a href="forms-uploads.html">File Uploads</a></li>
            </ul>
        </li>

        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect"><i
                    class="feather-box"></i><span>Icons</span></a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="icons-materialdesign.html">Material Design</a></li>
                <li><a href="icons-fontawesome.html">Font awesome</a></li>
                <li><a href="icons-dripicons.html">Dripicons</a></li>
                <li><a href="icons-feather.html">Feather Icons</a></li>
            </ul>
        </li>

        <li class="menu-title">More</li>

        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect"><i
                    class="feather-map"></i><span>Maps</span></a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="maps-google.html">Google Maps</a></li>
                <li><a href="maps-vector.html">Vector Maps</a></li>
            </ul>
        </li>

        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect"><i
                    class="mdi mdi-share-variant"></i><span>Multi Level</span></a>
            <ul class="sub-menu" aria-expanded="true">
                <li><a href="javascript: void(0);">Level 1.1</a></li>
                <li><a href="javascript: void(0);" class="has-arrow">Level 1.2</a>
                    <ul class="sub-menu" aria-expanded="true">
                        <li><a href="javascript: void(0);">Level 2.1</a></li>
                        <li><a href="javascript: void(0);">Level 2.2</a></li>
                    </ul>
                </li>
            </ul>
        </li>

    </ul>
</div> --}}
